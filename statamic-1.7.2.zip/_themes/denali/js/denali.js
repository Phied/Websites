// theme js

// Photo gallery masonry layout
if ($('.masonry').length ) {
  $('.masonry').masonry({
  	itemSelector: '.item',
  	gutter: 15
  });
}