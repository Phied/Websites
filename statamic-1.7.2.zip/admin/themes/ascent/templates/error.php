<div class="container">

  <div class="error-block">
    <h1><?php echo Localization::fetch('error')?></h1>

    <p class="msg"><?php echo Localization::fetch($_GET['code']); ?></p>

    <a href="#" class="btn push-down go-back"><span class="ss-icon">directleft</span> Go back</a>

  </div>


</div>
