<div class="container">

    <div class="row">
      <div class="span8">
        <div class="panel">
          <?php echo Config::get('dashboard_main_content', '') ?>
        </div>
      </div>
      <div class="span4">
        <div class="panel topo">
          <?php echo Config::get('dashboard_sidebar_content', '') ?>
        </div>
      </div>
    </div>
  </div>

</div>
