<div id="screen">
  <h1><?php echo Localization::fetch('access_denied')?></h1>
</div>
