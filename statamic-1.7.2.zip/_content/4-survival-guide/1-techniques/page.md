---
title: Techniques
_template: section
---
There are some things you should know how to go about doing. These are just some of those things.