---
title: Survival Guide
_template: section
_fieldset: page
---
### I can teach you many things. Things that will keep you alive.