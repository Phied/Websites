---
title: Elk Spotting
---
The time to go into the woods once again and look for the majestic beast called Elk.