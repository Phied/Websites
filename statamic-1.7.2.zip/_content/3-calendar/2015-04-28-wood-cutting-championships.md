---
title: Wood-Cutting Championships
---
The only wood-cutting competition I care about is the one called "staying alive for another year."
I reign champion for 42 years and counting.