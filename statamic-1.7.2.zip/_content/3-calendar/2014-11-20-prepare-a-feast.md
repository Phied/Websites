---
title: Prepare a Feast
---
The harvest is complete, and now is the time to eat and spend time with those that matter most: my trusty axe and backpack.