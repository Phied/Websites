---
title: Wiseman’s Bluff
comment: In which we walked a ways into the woods.
where:
  name: 'Christmas Camp'
  latitude: '44.32931'
  longitude: '-68.21422'
---
We hiked through the woods for what seemed like both forever and no time at all.
We very well may have been going in circle.
It was cloudy, and we didn't keep good track of the local landmarks.