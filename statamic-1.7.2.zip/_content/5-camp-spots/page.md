---
title: Camp Spots
_template: map
_default_folder_template: single-map
include_maps: true
---