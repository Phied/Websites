---
title: 'Friend’s Ravine'
comment: 'A well of emotion and personal reflection.'
where:
  name: 'Another Place'
  latitude: '44.32858'
  longitude: '-68.20776'
---
They say you should never stumble into Friend’s Ravine on an empty stomach.
Of course, we broke the rules again, and paid the heavy price.