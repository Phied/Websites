---
title: 'Just Off the Road'
comment: 'A little spot off the road.'
where:
  name: 'Just Off the Road'
  latitude: '44.32974'
  longitude: '-68.2066'
---

Our next stop in our journey led us back to civilization.
We had found a road, and decided it was best to simply walk along it until we grew tired.
But the road is boring, and we grew tired quickly.