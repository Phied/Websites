---
title: Beauty on the Waves
categories:
  - survival
  - wilderness
  - ocean
  - cold
---
It is but a few degrees above freezing but I can't tear myself away from the shoreline. The waves crash against the rocks endlessly and with such fury! Every drop of water that sprays into the air is transfigured into a crystallene rainbow in the light of the setting sun. I fear for my safety, away from shelter, but I remain. Transfixed.

<img src="{{ _site_root }}assets/img/waves.jpg" />