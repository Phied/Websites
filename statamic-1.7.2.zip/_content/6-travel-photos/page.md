---
title: Travel Photos
_fieldset: gallery
_template: gallery
gallery:
  - 
    photo: /assets/img/beach.jpg
    caption: Beach
  - 
    photo: /assets/img/woods.jpg
    caption: Woods
  - 
    photo: /assets/img/waves.jpg
    caption: Waves
  - 
    photo: /assets/img/cloud.jpg
    caption: Cliff
  - 
    photo: /assets/img/maldives.jpg
    caption: The Maldives
  - 
    photo: /assets/img/plant.jpg
    caption: Plant
  - 
    photo: /assets/img/gull.jpg
    caption: Gull
  - 
    photo: /assets/img/cliff.jpg
    caption: Cloud
  - 
    photo: /assets/img/boat.jpg
    caption: Boat
---

Along our journey we encountered nothing but incredible scenes that needed capturing.
I felt as though I wasn't so much *taking* photos as I was *receiving* visual bounties from the landscape around me.
"Never forget this," it begged. And I haven't.

Although I'm mostly a private person, I feel compelled to share the beauty in the imagery I captured that day with the world.