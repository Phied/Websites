<?php

class Hooks extends Addon
{

}
