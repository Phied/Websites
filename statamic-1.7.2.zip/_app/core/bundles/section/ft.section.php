<?php
class Fieldtype_section extends Fieldtype
{
  public function render()
  {
    return "";
  }

}
